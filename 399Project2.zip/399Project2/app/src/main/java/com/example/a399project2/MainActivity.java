package com.example.a399project2;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.KeyEvent;
import android.os.Environment;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import android.graphics.pdf.PdfDocument;

public class MainActivity extends Activity {

    private static final int PICK_PDF_REQUEST = 1;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create a WebView to display the PDF
        webView = findViewById(R.id.webView);



        EditText gptSearch = findViewById(R.id.editText);

        gptSearch.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (i == KeyEvent.KEYCODE_ENTER)) {
                    // Perform action on key press
                    summarizeTextAsync(gptSearch.getText().toString());
                    return true;
                }
                return false;
            }
        });

        // Enable JavaScript for better PDF rendering
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);

        // Start the file picker intent
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        startActivityForResult(intent, PICK_PDF_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Check if the result comes from the file picker
        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri selectedPdfUri = data.getData();

            // Handle the selected PDF URI
            if (selectedPdfUri != null) {
                displayPdf(selectedPdfUri);
            } else {
                Toast.makeText(this, "Failed to retrieve PDF", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void displayPdf(Uri pdfUri) {
        try {
            // Open the selected PDF file
            InputStream inputStream = getContentResolver().openInputStream(pdfUri);

            // Load the PDF
            webView.loadUrl("about:blank"); // Clear previous content
            webView.loadDataWithBaseURL(null, readStream(inputStream), "application/pdf", "UTF-8", null);

            // Enable copying text
            webView.setOnLongClickListener(v -> {
                // Get selected text
                String selectedText = webView.getHitTestResult().getExtra();

                // Copy selected text to clipboard
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("SelectedText", selectedText);
                clipboard.setPrimaryClip(clip);

                // Summarize the copied text using ChatGPT API (not working)
                summarizeTextAsync(selectedText);

                Toast.makeText(this, "Text copied to clipboard", Toast.LENGTH_SHORT).show();

                return true;
            });
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading PDF", Toast.LENGTH_SHORT).show();
        }
    }

    private String readStream(InputStream inputStream) throws IOException {
        // Read the InputStream and convert it to a String
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
        }
        return stringBuilder.toString();
    }

    private void summarizeTextAsync(String inputText) {
        // API details
        String apiKey = "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";
        String apiEndpoint = "https://api.openai.com/v1/chat/completions";
        String model = "gpt-3.5-turbo";

        // Execute task on a separate thread
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(apiEndpoint);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                // Setting up the connection
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Authorization", "Bearer " + apiKey);
                urlConnection.setDoOutput(true);

                // JSON request body
                String body = "{\"model\": \"" + model + "\", \"messages\": [{\"role\": \"user\", \"content\": \"" + "Summarize this" +inputText + "\"}]}";
                urlConnection.setDoOutput(true);
                OutputStreamWriter os = new OutputStreamWriter(urlConnection.getOutputStream());
                os.write(body);
                os.flush();
                os.close();


                // Get response
                int responseCode = urlConnection.getResponseCode();
                String fullResponse = urlConnection.getResponseMessage();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Read and display the response
                    String result = readStream(urlConnection.getInputStream());
                    saveStringToPdf(result);
                    runOnUiThread(() -> {
                        Toast.makeText(this, result, Toast.LENGTH_LONG).show();
                    });
                } else {
                    // Handle the error
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Error Code: " + responseCode +" "+ fullResponse, Toast.LENGTH_SHORT).show();
                    });
                }
            } catch (IOException e) {
                e.printStackTrace();
                // Handle the exception
                runOnUiThread(() -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        });
    }
    private void saveStringToPdf(String content) {
    // Create a new PDF document
    PdfDocument document = new PdfDocument();

    // Creating page
    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(300, 600, 1).create();
    PdfDocument.Page page = document.startPage(pageInfo);

    // Create a canvas for drawing on the page
    android.graphics.Canvas canvas = page.getCanvas();

    // Setting up paint for drawing
    Paint paint = new Paint();
    paint.setColor(Color.BLACK);
    paint.setTextSize(12);

    // Break the content into lines
    String[] lines = content.split("\n");

    // Draw each line on the canvas
    float yPosition = 25; // Initial y position
    for (String line : lines) {
        canvas.drawText(line, 10, yPosition, paint);
        yPosition += 15; // Adjust for the next line
    }

    // Finish the page
    document.finishPage(page);

    // Save the document to a file
    try {
        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File file = new File(downloadsDir, "example.pdf");
        document.writeTo(new FileOutputStream(file));
        document.close();

        // Success Notification
        Toast.makeText(this, "PDF saved successfully", Toast.LENGTH_SHORT).show();
    } catch (IOException e) {
        e.printStackTrace();
        // Handle Exception
        Toast.makeText(this, "Error saving PDF", Toast.LENGTH_SHORT).show();
    }
}


}
